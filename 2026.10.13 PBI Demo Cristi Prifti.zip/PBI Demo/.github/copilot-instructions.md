# Project instructions

This repository contains a Power BI project saved as PBIP. The semantic model is stored as TMDL files under `*.SemanticModel/definition/`.

## How we work

- Edit the model through the TMDL files or the Power BI Authoring MCP server; never hand-edit generated report files you don't understand.
- Keep changes small and explain each one: what changed and why.
- After changing any `.tmdl` file, check it against our conventions with the `pbip-conventions` skill.
- Ask before renaming existing measures or tables: reports and other measures may reference them.

## Stack

- Power BI Desktop with PBIP, source control in Git.
- DAX formatted in the SQLBI style: one function per line for anything longer than one line.
