---
name: TMDL editing
description: Rules for editing TMDL files of a Power BI semantic model.
applyTo: '**/*.tmdl'
---
# Editing TMDL files

- TMDL is indentation-sensitive: keep tabs exactly as in the surrounding file.
- Put the description as a `///` line directly above the object it describes.
- Multi-line DAX goes on the lines after `=`, indented one level deeper than the measure's properties.
- Never change `lineageTag` values: they identify objects across versions.
