---
name: review-measures
description: Review the measures of a semantic model table for naming, descriptions and format strings.
argument-hint: "table name"
agent: ask
---
# Review measures

Review the measures in the table ${input:table:financials} of this repository's semantic model.

For each measure, report:

1. Whether the name follows our conventions (see [the conventions reference](../skills/pbip-conventions/references/conventions.md)).
2. Whether it has a business-friendly description.
3. Whether it has a formatString that fits the kind of value.

Finish with a short table: measure, issue, suggested fix. Do not edit any files.

<!-- Legacy example: prompt files load only in the Local harness. The migrated version is the review-measures skill. -->
