---
name: pbip-conventions
description: Apply and check the team's Power BI semantic model conventions (measure naming, descriptions, format strings, table names) in PBIP/TMDL files. Use when creating, renaming or reviewing measures or tables, or when asked to check a semantic model against our conventions.
argument-hint: "TMDL file or folder to check"
---

# PBIP conventions

Our semantic models are stored as PBIP, with the model in TMDL files. Follow these rules whenever you create or change measures or tables.

## The rules

1. **Measure names** are business names in plain words: `Total Sales`, `Order Count`. No underscores, no technical prefixes (`m_`, `msr`, `Measure`), no double or trailing spaces.
2. **Every measure has a description**: a `///` line directly above the `measure` line, written for a business user.
3. **Every measure has a `formatString`.**
4. **Table names** are business names: `Sales`, not `DimSales` or `Fact_Sales`.

Detailed guidance, with examples of good and bad names, is in [the conventions reference](./references/conventions.md). Read it when you are unsure how to name something.

## How to check

After changing any `.tmdl` file, run the [check script](./scripts/check-tmdl.cjs) on the files you changed:

```
node .github/skills/pbip-conventions/scripts/check-tmdl.cjs <file-or-folder>
```

- Exit code 0: the files follow the conventions.
- Exit code 1: the script lists each violation with its line number and rule (R1–R4). Fix them and run it again.

Do not rename a measure that reports or other measures already reference without telling the user: renames break those references.
