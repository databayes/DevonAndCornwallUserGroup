# Semantic model conventions: details and examples

This file is loaded only when the skill links to it, so it can be as detailed as needed.

## R1: measure names

| Avoid | Use instead | Why |
|---|---|---|
| `m_TotalSales` | `Total Sales` | Report users see measure names in field lists and tooltips |
| `Sales_LY` | `Total Sales LY` | Underscores read as technical leftovers |
| `Measure 1` | `Order Count` | Says nothing about the business meaning |
| `Sales  LY` | `Total Sales LY` | Double spaces are invisible in the UI but break lookups |

Time-intelligence suffixes are short and consistent: `LY`, `YTD`, `MTD`, `YoY %`.

## R2: descriptions

Write the description for a business user, in one sentence, and say what is included or excluded:

```
/// Total sales amount, before returns
measure 'Total Sales' = SUM ( Sales[Amount] )
```

Descriptions show up as tooltips in Power BI and are read by Copilot and data agents, so they double as AI-readiness metadata.

## R3: format strings

| Kind of value | formatString |
|---|---|
| Amounts | `#,0.00` |
| Counts | `#,0` |
| Percentages | `0.0%` |

## R4: table names

Use the business entity: `Sales`, `Customer`, `Date`. Star-schema roles (dimension, fact) belong in documentation, not in names users see.

## Display folders (recommended, not checked)

Group measures by topic with `displayFolder`, for example `Revenue`, `Orders`.
