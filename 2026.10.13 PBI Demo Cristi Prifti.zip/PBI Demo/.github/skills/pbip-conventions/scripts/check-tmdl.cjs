#!/usr/bin/env node
/*
 * check-tmdl.cjs — validates TMDL files against the team's semantic model conventions.
 *
 * Two modes, one rule set:
 *   CLI:   node check-tmdl.cjs <file-or-folder> [...]      (used by the pbip-conventions skill)
 *   Hook:  node check-tmdl.cjs --hook < event.json         (used by .github/hooks/validate-tmdl.json)
 *
 * In hook mode the script reads the PostToolUse event from stdin, finds any .tmdl
 * paths in tool_input, checks only those files and, when a rule is broken, answers
 * with decision "block" so the agent sees the violations and fixes them.
 *
 * Rules (edit RULES below to match your own conventions):
 *   R1  Measure names: no underscores, no technical prefixes (m_, msr, measure), no stray spaces
 *   R2  Every measure has a description (/// line directly above it)
 *   R3  Every measure has a formatString
 *   R4  Table names: no Dim/Fact prefixes (users read these names)
 */
'use strict';

const fs = require('node:fs');
const path = require('node:path');

const RULES = {
  forbiddenMeasurePrefixes: [/^m_/i, /^msr/i, /^measure\b/i],
  forbiddenTablePrefixes: [/^dim[_ ]?/i, /^fact[_ ]?/i],
};

// ---------- TMDL helpers ----------

function unquote(name) {
  const n = name.trim();
  if (n.startsWith("'") && n.endsWith("'")) return n.slice(1, -1).replace(/''/g, "'");
  return n;
}

function indentOf(line) {
  const m = line.match(/^[\t ]*/);
  return m[0].replace(/\t/g, '    ').length;
}

const TABLE_RE = /^\s*table\s+('(?:[^']|'')+'|[^\s=]+)/;
const MEASURE_RE = /^(\s*)measure\s+('(?:[^']|'')+'|[^\s=]+)\s*=/;

function checkFile(file) {
  const text = fs.readFileSync(file, 'utf8');
  const lines = text.split(/\r?\n/);
  const issues = [];

  lines.forEach((line, i) => {
    const t = line.match(TABLE_RE);
    if (t) {
      const name = unquote(t[1]);
      if (RULES.forbiddenTablePrefixes.some((re) => re.test(name))) {
        issues.push({ line: i + 1, rule: 'R4', msg: `Table '${name}' uses a Dim/Fact prefix; use a business name instead.` });
      }
    }

    const m = line.match(MEASURE_RE);
    if (!m) return;
    const name = unquote(m[2]);
    const ownIndent = indentOf(line);

    // R1 naming
    if (name.includes('_')) issues.push({ line: i + 1, rule: 'R1', msg: `Measure '${name}' contains an underscore.` });
    if (RULES.forbiddenMeasurePrefixes.some((re) => re.test(name))) {
      issues.push({ line: i + 1, rule: 'R1', msg: `Measure '${name}' uses a technical prefix.` });
    }
    if (name !== name.trim() || /\s{2,}/.test(name)) {
      issues.push({ line: i + 1, rule: 'R1', msg: `Measure '${name}' has leading, trailing or double spaces.` });
    }

    // R2 description: nearest non-empty line above must be a /// comment
    let j = i - 1;
    while (j >= 0 && lines[j].trim() === '') j--;
    if (j < 0 || !lines[j].trim().startsWith('///')) {
      issues.push({ line: i + 1, rule: 'R2', msg: `Measure '${name}' has no description (add a /// line above it).` });
    }

    // R3 formatString: look in the measure's own block (deeper-indented lines)
    let hasFormat = false;
    for (let k = i + 1; k < lines.length; k++) {
      const l = lines[k];
      if (l.trim() === '') continue;
      if (indentOf(l) <= ownIndent) break;
      if (/^\s*formatString\s*:/.test(l)) { hasFormat = true; break; }
    }
    if (!hasFormat) issues.push({ line: i + 1, rule: 'R3', msg: `Measure '${name}' has no formatString.` });
  });

  return issues;
}

function collectTmdl(target) {
  if (!fs.existsSync(target)) return [];
  const stat = fs.statSync(target);
  if (stat.isFile()) return target.toLowerCase().endsWith('.tmdl') ? [target] : [];
  return fs.readdirSync(target, { withFileTypes: true }).flatMap((d) => {
    if (d.name === 'node_modules' || d.name.startsWith('.git')) return [];
    return collectTmdl(path.join(target, d.name));
  });
}

function report(results) {
  return results
    .map(({ file, issues }) => [`${file}`, ...issues.map((x) => `  line ${x.line} [${x.rule}] ${x.msg}`)].join('\n'))
    .join('\n');
}

// ---------- Hook mode ----------

function findTmdlPaths(value, out = new Set()) {
  if (typeof value === 'string') {
    for (const m of value.matchAll(/[^\s"'<>|]+\.tmdl\b/gi)) out.add(m[0]);
  } else if (Array.isArray(value)) {
    value.forEach((v) => findTmdlPaths(v, out));
  } else if (value && typeof value === 'object') {
    Object.values(value).forEach((v) => findTmdlPaths(v, out));
  }
  return out;
}

function runHook() {
  let input = '';
  process.stdin.setEncoding('utf8');
  process.stdin.on('data', (chunk) => (input += chunk));
  process.stdin.on('end', () => {
    let event = {};
    try { event = JSON.parse(input || '{}'); } catch { /* not JSON: nothing to check */ }
    const cwd = event.cwd || process.cwd();
    const files = [...findTmdlPaths(event.tool_input)]
      .map((p) => (path.isAbsolute(p) ? p : path.join(cwd, p)))
      .filter((p) => fs.existsSync(p));

    const results = files.map((file) => ({ file: path.relative(cwd, file), issues: checkFile(file) }))
      .filter((r) => r.issues.length > 0);

    if (results.length === 0) {
      process.stdout.write(JSON.stringify({ continue: true }));
      return;
    }
    const details = report(results);
    process.stdout.write(JSON.stringify({
      decision: 'block',
      reason: `TMDL conventions check failed. Fix these and re-check:\n${details}`,
      hookSpecificOutput: {
        hookEventName: 'PostToolUse',
        additionalContext: 'Conventions are defined in the pbip-conventions skill (.github/skills/pbip-conventions).',
      },
    }));
  });
}

// ---------- CLI mode ----------

function runCli(args) {
  const targets = args.length ? args : ['.'];
  const files = targets.flatMap(collectTmdl);
  if (files.length === 0) {
    console.log('No .tmdl files found.');
    return 0;
  }
  const results = files.map((file) => ({ file, issues: checkFile(file) })).filter((r) => r.issues.length > 0);
  if (results.length === 0) {
    console.log(`OK: ${files.length} TMDL file(s) follow the conventions.`);
    return 0;
  }
  const total = results.reduce((n, r) => n + r.issues.length, 0);
  console.log(report(results));
  console.log(`\n${total} issue(s) in ${results.length} file(s).`);
  return 1;
}

const args = process.argv.slice(2);
if (args[0] === '--hook') runHook();
else process.exitCode = runCli(args);
