---
name: review-measures
description: Use when asked to review the measures of a semantic model table for naming, descriptions and format strings, and report findings without editing files. Use when the user runs /review-measures.
argument-hint: "table name"
disable-model-invocation: true
---

# Review measures

This is the migrated version of `.github/prompts/review-measures.prompt.md`. `disable-model-invocation: true` keeps it manual: it runs only when someone types `/review-measures`, just like the prompt file did.

1. Find the TMDL file for the table the user named (default: `financials`).
2. Run the [check script](../pbip-conventions/scripts/check-tmdl.cjs) on that file to get the rule violations.
3. For each measure, report whether the name, description and formatString follow [our conventions](../pbip-conventions/references/conventions.md).
4. Finish with a short table: measure, issue, suggested fix.

Do not edit any files: this skill only reports.
