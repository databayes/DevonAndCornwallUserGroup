# Power BI Report Authoring Skills - Prerequisites

Last checked: 12 October 2026.

This checklist covers the `powerbi-report-cli` skill's planning, design, local report authoring, preview, and optional publishing workflows. Requirements depend on the workflow; cloud licensing and tools are not prerequisites for every local report.

## 1. Minimum requirements by workflow

| Workflow | Required | Not required for this workflow |
|---|---|---|
| Planning and design | An agent host with the Power BI report skill loaded; report requirements; access to the relevant model metadata; approval of the proposed design before building | A Fabric workspace, publishing permissions, or a report-authoring CLI solely to discuss a design |
| Local report-file authoring | Node.js 20 or later; npm; Microsoft's report-authoring CLI; readable/writable PBIP/PBIR project files; a valid semantic-model binding; approval to edit the project | Fabric capacity, Azure CLI, Python, Power BI Report Builder |
| Local live-model inspection or edits | Registered and running Power BI Modeling MCP; acceptance of its EULA; a Power BI Desktop file open with a loaded model; explicit approval for model writes | A published semantic model or service-side XMLA capacity for this local Desktop route |
| Desktop rendering and screenshot verification | Windows; a compatible Power BI Desktop installation; the report's owning PBIP file; the CLI's Desktop preview host available; an interactive session; a safe saved Desktop state before automated loading | A Fabric workspace or published report |
| Service rendering | A published semantic model; authenticated access; workspace and semantic-model IDs; appropriate model permissions/licensing; supported service preview and browser components | Publishing the local report merely to preview its layout |
| Fabric publishing | Explicit publishing approval; target workspace; authenticated API access and suitable permissions/licensing; the management workflow's REST tooling | Publishing authorization cannot be inferred from approval to edit or preview |

## 2. Agent and file-access prerequisites

- Use an agent host that can load the report skill and invoke local commands, read files, and write approved project files. This session uses Copilot SDK in VS Code.
- Install/load the Microsoft Power BI authoring plugin or equivalent registered skills. The report skill provides workflow guidance; it is not the report-authoring executable.
- Give the agent the full project folder location.
- Make the project readable and writable by the same user running the agent.
- Keep the report and model folders together so relative bindings resolve.
- Approve the page/design specification before implementation.
- Keep a backup or version-control history. Git is recommended, not mandatory.
- Do not grant cloud publishing permissions for a local-only task.
- Follow organisational rules for installing software, connecting to data, and handling report information.

## 3. Node.js, npm, and the report-authoring CLI

### Required versions and package

- Node.js: **20 or later**, according to the installed skill and CLI environment check.
- npm: available with Node.js.
- Package: **`@microsoft/powerbi-report-authoring-cli`**.
- Executable: **`powerbi-report-author`**.
- Install from the public **`@latest`** channel. Do not copy a repository evaluation's pinned prerelease into normal user setup.
- Allow access to the npm registry for initial installation and updates, or use an organisation-approved package mirror.
- Make the npm executable directory available on PATH, or invoke its executable by absolute path.
- Allow local command execution under the organisation's application-control policies.

### Installation and checks on Windows

Run in PowerShell:

```powershell
node --version
npm.cmd --version
npm.cmd install -g @microsoft/powerbi-report-authoring-cli@latest
powerbi-report-author.cmd --version
powerbi-report-author.cmd doctor --pretty
```

Using `.cmd` avoids invoking npm's or the CLI's PowerShell script shims when script execution is restricted. Do not weaken execution policy just to run the tool.

The CLI supplies visual capability metadata, formatting metadata, expression helpers, and PBIR validation dependencies. Its `doctor` command checks Node.js, the validator dependency, and the visual metadata provider. A successful doctor result does **not** prove that a rendering host is available.

Network requirements differ by command. Package installation needs registry access; fetching current schemas during scaffolding needs access to the public schema source. Scaffolding supports an offline pinned-schema mode. Do not send report data to public troubleshooting sites.

Full schema validation also needs access to the public schemas. On this machine, PowerShell could reach them but the initial Node.js validation could not. With Node.js 26.2.0, enabling system certificate authorities and environment-proxy support for the validation process resolved the issue:

```powershell
$env:NODE_USE_SYSTEM_CA = '1'
$env:NODE_USE_ENV_PROXY = '1'
powerbi-report-author.cmd validate 'C:\path\to\Report.Report'
```

Use these settings only where supported by the installed Node.js version and consistent with organisational network configuration. They do not disable certificate verification. Do not use `NODE_TLS_REJECT_UNAUTHORIZED=0` as a workaround. Schema-unreachable warnings mean full schema validation has not occurred, even if other checks pass.

## 4. Power BI project and report-format prerequisites

- Save the report in Power BI Desktop using **File > Save as > Power BI Project (.pbip)**.
- Use the **enhanced report format (PBIR)**, not only the legacy monolithic report definition.
- In older Desktop builds, the relevant project/report-format options may be preview features. Current availability depends on the installed Desktop version.
- A local report/model project normally contains:
  - A `.pbip` entry file.
  - A `.Report` folder with `definition.pbir`.
  - A `.Report\definition` folder containing report, page, and visual definitions.
  - A `.SemanticModel` folder when the report uses a local model.
- The report's `definition.pbir` must point to the intended model. Local `byPath` bindings use relative paths, not an ephemeral Desktop localhost port.
- Preserve the existing JSON schema versions when editing an existing project.
- The owning `.pbip` file is required for the CLI's Desktop preview route.
- A PBIX alone is enough for live model inspection through MCP, but not for this file-based report-authoring workflow.
- Source credentials are needed if a source refresh is required. Do not refresh sources unnecessarily for layout-only changes.

## 5. Semantic-model tooling prerequisites

Power BI Modeling MCP is a separate tool from the report-authoring CLI.

- Register it in the agent host and confirm the connection tools are available.
- Review and accept its EULA before its first use. Acceptance must be explicitly authorised by the user.
- For a local Desktop model, open the intended file/project and allow its model to load.
- Discover the running instance rather than hardcoding its port.
- Reconnect after closing/reopening Desktop: process, port, and database identifiers can change.
- Inspect tables, columns, measures, and relationships before binding report visuals.
- Create explicit measures for report metrics when the model lacks them, with formats and descriptions.
- Use the live MCP model as the source of truth while connected. Persist approved changes back into the PBIP model definition.
- Verify measures with DAX. A measure existing in the model does not prove its calculation is correct.
- Local PBIR-only edits do not inherently require MCP. Live model changes and testing do.
- If working against a model in the service, permissions, authentication, and any XMLA/capacity requirements must be checked for that connection route.

## 6. Desktop preview and completion prerequisites

For local report work, check Desktop through the report-authoring CLI, not by bypassing it with an underlying host tool:

```powershell
powerbi-report-author.cmd preview "C:\path\to\Report.Report" --host desktop --status
```

- The installed CLI, preview integration, Desktop build, and matching live report must support the requested operation.
- Power BI Desktop must be able to open the project and load its data/model.
- For automatic opening, the CLI must also locate `PBIDesktop.exe`. If discovery fails, configure `PBI_DESKTOP_PATH` to the actual executable path in the environment running the CLI. Attaching to an already open report and capturing it can work even when automatic executable discovery fails.
- Save or manually resolve unsaved Desktop edits before the agent loads externally modified project files. The agent must not silently discard live changes.
- If the files have already been edited externally, saving an older live Desktop layout can overwrite those edits. Resolve this deliberately: preserve any separate user changes first, then reopen the project from disk. Do not blindly save the older layout as a way to clear the safety gate.
- Use a visible, interactive Windows session for Desktop rendering.
- Validate edited PBIR, load the latest definition, then capture and review every affected page.
- Run loading/reloading and screenshot capture as separate commands.
- If model definitions change, loading them and processing the live model are separate steps; measures/metadata usually need Calculate rather than a source-data refresh.
- Schema validation alone is insufficient: blank visuals, clipped text, bad contrast, stale data, and rendering problems require screenshot review.
- `HOST_UNAVAILABLE` or `CAPABILITY_UNSUPPORTED` is a real blocker, not permission to change hosts or bypass the preview integration.
- Mandatory validation screenshots use a workflow-owned temporary directory outside the project and are cleaned up afterward. Retained screenshots need a separate explicit request; screenshots can expose report data.
- If rendering verification cannot be completed, the report must be described as not fully verified.

### Microsoft Store installation observed on this machine

The CLI could attach to the open report and capture it, but automatic opening returned `DESKTOP_EXE_NOT_FOUND`. The running Desktop executable was subsequently identified at:

```text
C:\Program Files\WindowsApps\Microsoft.MicrosoftPowerBIDesktop_2.158.1304.0_x64__8wekyb3d8bbwe\bin\pbidesktop.exe
```

For a future launch, the corresponding process-scoped PowerShell setting is:

```powershell
$env:PBI_DESKTOP_PATH = 'C:\Program Files\WindowsApps\Microsoft.MicrosoftPowerBIDesktop_2.158.1304.0_x64__8wekyb3d8bbwe\bin\pbidesktop.exe'
```

Run the CLI from that same environment. Store updates can change this path; identify the installed executable again after an update rather than assuming this versioned location is permanent. This setting has been documented, not applied persistently or launch-tested. Manual opening followed by CLI screenshots was successfully verified.

Desktop reported unsaved state during this build, so the user manually reopened the latest project rather than the agent discarding changes. Report rendering and interaction checks were then completed against that reopened project.

## 7. Conditional cloud prerequisites

These are **not needed for this local Sales Overview build**.

### Service preview

- An authenticated account with the required access to the published semantic model, typically including Build permission.
- The correct workspace ID and semantic-model ID.
- Licensing appropriate to the workspace/model and tenant policies.
- Network access to the service and the preview route's browser/authentication components.
- Service preview uses the published model's data; unpublished local model changes are not automatically available there.

### Publishing and service-side model management

- Explicit permission from the user to publish.
- A workspace and suitable item/workspace permissions.
- Appropriate Power BI/Fabric licensing. Pro, PPU, and capacity requirements depend on the scenario; Premium/Fabric capacity is not a universal local-authoring prerequisite.
- REST authentication and the management skill's tooling, normally Azure CLI for `az rest`.
- Correct API token audiences, tenant settings, and API permissions.
- Capacity and XMLA configuration where the selected service-side modeling operation requires them.
- Gateway/cloud connection and source credentials where refresh requires them.
- Successful operation polling and readback verification.

## 8. Current project readiness

| Check | Result on this machine |
|---|---|
| Agent host and report skills | Available |
| Approved report specification | Available; single-page editorial Sales Overview |
| Project location | This folder |
| PBIP entry file | [Sales Overview.pbip](./Sales%20Overview.pbip) |
| Enhanced PBIR definition | Present in [Sales Overview.Report](./Sales%20Overview.Report) |
| Model binding | Relative `byPath` to `../Sales Overview.SemanticModel` |
| Report content | One FHD page, Sales at a glance; four cards, three charts, three slicers, and two textboxes. The original page was blank. |
| Node.js | 26.2.0; passes the CLI's >=20 check |
| Report-authoring CLI | 0.5.0, installed from the public latest channel |
| CLI doctor | Passed Node.js, AJV, and metadata-provider checks |
| Visual metadata | Available: 57 visual types and 15 shared container objects |
| Modeling MCP | Six approved measures created, tested, exported into the project, and verified again after reopening |
| Modeling MCP EULA | Accepted with the user's explicit authorisation earlier in this session |
| Desktop binary | Store package 2.158.1304.0; observed binary product version 17.0.87.18, release branch 2026/08.4. These are verified installed versions, not claimed minimum supported versions. |
| Desktop preview readiness | Passed: latest project manually reopened, page captured through the Desktop host, and screenshots reviewed |
| Desktop automatic launch | Executable discovery failed; actual executable path and the conditional `PBI_DESKTOP_PATH` setting are documented above |
| Report definition validation | Full schema and authoring validation passed with zero errors and zero warnings after enabling the Node.js settings above |
| Rendered interaction checks | Passed: Enterprise losses, Paseo cross-filtering and fractional units, partial-year 2013, and restoration of unfiltered totals |
| Cloud prerequisites | Not applicable; no publishing requested |
| Python | Not required |
| Git | Optional; not required for this build |

## 9. Reusable preflight checklist

- [ ] Report skill loaded and local file/command access available.
- [ ] Requirements and design approved.
- [ ] Node.js >=20 and npm available.
- [ ] Latest public report-authoring CLI installed and runnable.
- [ ] CLI doctor passes.
- [ ] Correct editable PBIP/PBIR project and model binding identified.
- [ ] Project is writable and original content is backed up.
- [ ] Model fields and measures verified; MCP connected if live model work is needed.
- [ ] Required EULAs explicitly accepted.
- [ ] Appropriate preview host available and safe saved state confirmed.
- [ ] PBIR schema validation and fresh screenshot review planned.
- [ ] Cloud authentication, permissions, licensing, and publishing approval checked only if the workflow uses cloud operations.

## References

- [Microsoft Power BI authoring skills](https://github.com/microsoft/skills-for-fabric/tree/main/plugins/powerbi-authoring)
- [Power BI Desktop projects](https://learn.microsoft.com/en-us/power-bi/developer/projects/projects-overview)
- [Power BI project report folder and PBIR](https://learn.microsoft.com/en-us/power-bi/developer/projects/projects-report)
- [Power BI project semantic-model folder](https://learn.microsoft.com/en-us/power-bi/developer/projects/projects-dataset)
- [Microsoft report-authoring CLI package](https://www.npmjs.com/package/@microsoft/powerbi-report-authoring-cli)

CLI installation guidance and the Node.js minimum were also verified against the installed `powerbi-report-cli` authoring reference and the installed CLI's `doctor` output.
