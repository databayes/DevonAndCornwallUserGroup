# MCPs, Skills and Plugins: showcase repo

Companion repo for the session **MCPs, Skills and Plugins** (ByteWise). Every concept in the deck is a real file here, so you can walk through them in VS Code instead of demoing live.

## What's inside

| File | Concept (slide) | What to show |
|---|---|---|
| `.github/copilot-instructions.md` | Instructions, always on | Project-wide rules every request gets |
| `.github/instructions/tmdl.instructions.md` | Instructions, scoped | `applyTo: '**/*.tmdl'`: only loads for TMDL edits |
| `.github/skills/pbip-conventions/SKILL.md` | Skills | The "manual": short, with links to the details and the script |
| `…/pbip-conventions/references/conventions.md` | Progressive loading | Loaded only when the skill links to it |
| `…/pbip-conventions/scripts/check-tmdl.cjs` | Skills bring tools | The script checks rules R1–R4 |
| `.github/prompts/review-measures.prompt.md` | Prompt files (legacy) | Manual `/review-measures`, Local harness only |
| `.github/skills/review-measures/SKILL.md` | Migrating to skills | Same workflow as a skill with `disable-model-invocation: true` |
| `.github/agents/model-reviewer.agent.md` | Custom agents | Read-only reviewer with MCP tools and a "Fix the issues" handoff |
| `.github/hooks/validate-tmdl.json` | Hooks | PostToolUse: reuses the skill's script to block bad TMDL edits |
| `.mcp.json` | MCP servers | Power BI Authoring (local, npx) + Microsoft Learn (hosted) |
| `plugin/bytewise-pbip/` | Plugins | Skill + agent + MCP config packaged as one installable unit |
| `Sales Overview.pbip` + `.Report` + `.SemanticModel` | The real project | PBIP/PBIR report on the `financials` table, 6 measures, already following the conventions |
| `samples/financials.with-violations.tmdl` | Before | The same `financials` table plus 3 bad measures (7 findings) |
| `samples/Sales.*.tmdl` | Checker demo | A tiny clean table and a tiny broken one |
| `docs/POWER-BI-AUTHORING-PREREQUISITES.md` | Prerequisites | Your detailed checklist for the report-authoring workflow |

The key story: **the hook enforces what the manual describes.** The skill and the hook call the same `check-tmdl.cjs`, so the rules live in one place.

## Try the checker (no agent needed)

```
node .github/skills/pbip-conventions/scripts/check-tmdl.cjs samples
```

`Sales.clean.tmdl` passes. `Sales.violations.tmdl` reports 7 issues: a Dim prefix, an `m_` measure with no description or format string, and a measure name with a double space. This makes a good screenshot for the skills slide.

Run it on the real model too: `node .github/skills/pbip-conventions/scripts/check-tmdl.cjs "Sales Overview.SemanticModel"` passes, and `samples/financials.with-violations.tmdl` shows 7 findings.

## Set up for the session

1. Prerequisites from the deck: VS Code + GitHub Copilot, Node.js 22+, Git, and the "MCP servers in Copilot" policy if you're on a Business or Enterprise plan.
2. Open `Sales Overview.pbip` in Power BI Desktop once, so the model loads and the cache is rebuilt (the `.pbi/cache.abf` file is git-ignored and not included).
3. For the "before" state, copy `samples/financials.with-violations.tmdl` over `Sales Overview.SemanticModel/definition/tables/financials.tmdl`. It adds `m_GrossSales`, `COGS_Total` and `Sales  per Unit`.

## Demo plan: pre-baked branches

Run each scenario the day before and commit the result to its own branch. On stage, switch branches and show the diff: it looks live, nothing can break.

| Branch | Run beforehand | Show on stage |
|---|---|---|
| `01-before` | Copy in `financials.with-violations.tmdl` and commit | The 3 bad measures, plus the checker output (7 findings) |
| `02-skill` | Ask the agent: "Add a Net Sales YTD measure to financials" | New measure follows the conventions; References show `pbip-conventions` loaded |
| `03-hook` | Ask the agent to add a measure called `m_Test` to financials | Hook blocks it, the agent fixes the name, description and format |
| `04-reviewer` | Run the Model Reviewer agent on `financials` (from `01-before`) | Its findings table and the "Fix the issues" handoff |
| `05-mcp` | Ask the agent to list measures through the Authoring MCP | The expanded tool call and its result |

## Screenshots to capture

- [ ] Chat response with **References** expanded: copilot-instructions, tmdl.instructions, pbip-conventions SKILL.md
- [ ] Checker output on `samples/` (terminal)
- [ ] Hook blocking an edit (the decision "block" with the violation list), then the corrected TMDL
- [ ] Expanded MCP tool call from the Power BI Authoring server
- [ ] `/` menu showing `review-measures` as both a prompt file and a skill (see note below)
- [ ] Agent Customizations editor listing skills, agents, hooks and MCP servers
- [ ] Plugin installed from `plugin/bytewise-pbip` (Plugins page)
- [ ] Duplicate skill-name experiment: same skill name in `~/.copilot/skills/` and `.github/skills/`

## Short recordings (60–90 s, silent, narrate live)

1. The agent picking up `pbip-conventions` on its own for a measure request.
2. The hook firing and the agent fixing its own mistake.

## Notes and caveats

- **Hooks:** this hook uses the Local harness format. In a Copilot (Agent Host) session, hooks follow the Copilot SDK schema, so test in the harness you'll show. Hooks are Preview and need `chat.useHooks` and a trusted workspace.
- **Tool names:** the hook doesn't filter by tool name, because tool names differ between harnesses. It looks for `.tmdl` paths in the tool input instead.
- **Prompt file and skill share the name `review-measures` on purpose.** That shows the migration, but it's also the "same name" attention point from the skills slide. Keep only one active outside the demo.
- **Plugin:** it contains the skill, agent and MCP config. The hook is left out because plugin hook commands need the plugin-root path token; see "hooks in plugins" in the VS Code docs before adding it. Install with `chat.pluginLocations` pointing at `plugin/bytewise-pbip`, or **Chat: Install Plugin From Source** once the repo is on GitHub. Plugin skills get the plugin name as a namespace, so they don't clash with the repo copy.
- **Conventions:** R1–R4 are sensible defaults. Replace them with your own rules in `SKILL.md`, `references/conventions.md` and the `RULES` block of `check-tmdl.cjs`.
